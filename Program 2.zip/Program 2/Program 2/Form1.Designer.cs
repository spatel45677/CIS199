﻿namespace Program_2
{
    partial class program_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.taxable_income_text = new System.Windows.Forms.TextBox();
            this.taxable_income_label = new System.Windows.Forms.Label();
            this.tax_filing_status_label = new System.Windows.Forms.Label();
            this.married_filing_jointly_radio = new System.Windows.Forms.RadioButton();
            this.married_filing_separately_radio = new System.Windows.Forms.RadioButton();
            this.single_radio = new System.Windows.Forms.RadioButton();
            this.head_of_household_radio = new System.Windows.Forms.RadioButton();
            this.calculate_button = new System.Windows.Forms.Button();
            this.income_tax_output = new System.Windows.Forms.Label();
            this.income_tax_label = new System.Windows.Forms.Label();
            this.tax_rate_label = new System.Windows.Forms.Label();
            this.tax_rate_output = new System.Windows.Forms.Label();
            this.clear_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // taxable_income_text
            // 
            this.taxable_income_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxable_income_text.Location = new System.Drawing.Point(203, 28);
            this.taxable_income_text.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.taxable_income_text.Name = "taxable_income_text";
            this.taxable_income_text.Size = new System.Drawing.Size(133, 23);
            this.taxable_income_text.TabIndex = 0;
            // 
            // taxable_income_label
            // 
            this.taxable_income_label.AutoSize = true;
            this.taxable_income_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxable_income_label.Location = new System.Drawing.Point(31, 28);
            this.taxable_income_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.taxable_income_label.Name = "taxable_income_label";
            this.taxable_income_label.Size = new System.Drawing.Size(168, 20);
            this.taxable_income_label.TabIndex = 1;
            this.taxable_income_label.Text = "Enter Taxable Income:";
            // 
            // tax_filing_status_label
            // 
            this.tax_filing_status_label.AutoSize = true;
            this.tax_filing_status_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tax_filing_status_label.Location = new System.Drawing.Point(51, 72);
            this.tax_filing_status_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.tax_filing_status_label.Name = "tax_filing_status_label";
            this.tax_filing_status_label.Size = new System.Drawing.Size(116, 17);
            this.tax_filing_status_label.TabIndex = 2;
            this.tax_filing_status_label.Text = "Tax Filing Status:";
            // 
            // married_filing_jointly_radio
            // 
            this.married_filing_jointly_radio.AutoSize = true;
            this.married_filing_jointly_radio.Location = new System.Drawing.Point(167, 91);
            this.married_filing_jointly_radio.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.married_filing_jointly_radio.Name = "married_filing_jointly_radio";
            this.married_filing_jointly_radio.Size = new System.Drawing.Size(119, 17);
            this.married_filing_jointly_radio.TabIndex = 3;
            this.married_filing_jointly_radio.TabStop = true;
            this.married_filing_jointly_radio.Text = "Married Filing Jointly";
            this.married_filing_jointly_radio.UseVisualStyleBackColor = true;
            // 
            // married_filing_separately_radio
            // 
            this.married_filing_separately_radio.AutoSize = true;
            this.married_filing_separately_radio.Location = new System.Drawing.Point(167, 112);
            this.married_filing_separately_radio.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.married_filing_separately_radio.Name = "married_filing_separately_radio";
            this.married_filing_separately_radio.Size = new System.Drawing.Size(140, 17);
            this.married_filing_separately_radio.TabIndex = 4;
            this.married_filing_separately_radio.TabStop = true;
            this.married_filing_separately_radio.Text = "Married Filing Separately";
            this.married_filing_separately_radio.UseVisualStyleBackColor = true;
            // 
            // single_radio
            // 
            this.single_radio.AutoSize = true;
            this.single_radio.Location = new System.Drawing.Point(167, 72);
            this.single_radio.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.single_radio.Name = "single_radio";
            this.single_radio.Size = new System.Drawing.Size(54, 17);
            this.single_radio.TabIndex = 5;
            this.single_radio.TabStop = true;
            this.single_radio.Text = "Single";
            this.single_radio.UseVisualStyleBackColor = true;
            // 
            // head_of_household_radio
            // 
            this.head_of_household_radio.AutoSize = true;
            this.head_of_household_radio.Location = new System.Drawing.Point(167, 133);
            this.head_of_household_radio.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.head_of_household_radio.Name = "head_of_household_radio";
            this.head_of_household_radio.Size = new System.Drawing.Size(117, 17);
            this.head_of_household_radio.TabIndex = 6;
            this.head_of_household_radio.TabStop = true;
            this.head_of_household_radio.Text = "Head of Household";
            this.head_of_household_radio.UseVisualStyleBackColor = true;
            // 
            // calculate_button
            // 
            this.calculate_button.AutoSize = true;
            this.calculate_button.BackColor = System.Drawing.Color.LightGreen;
            this.calculate_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculate_button.Location = new System.Drawing.Point(251, 184);
            this.calculate_button.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.calculate_button.Name = "calculate_button";
            this.calculate_button.Size = new System.Drawing.Size(94, 30);
            this.calculate_button.TabIndex = 7;
            this.calculate_button.Text = "Calculate";
            this.calculate_button.UseVisualStyleBackColor = false;
            this.calculate_button.Click += new System.EventHandler(this.calculate_button_Click);
            // 
            // income_tax_output
            // 
            this.income_tax_output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.income_tax_output.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.income_tax_output.Location = new System.Drawing.Point(175, 245);
            this.income_tax_output.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.income_tax_output.Name = "income_tax_output";
            this.income_tax_output.Size = new System.Drawing.Size(161, 26);
            this.income_tax_output.TabIndex = 8;
            this.income_tax_output.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // income_tax_label
            // 
            this.income_tax_label.AutoSize = true;
            this.income_tax_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.income_tax_label.Location = new System.Drawing.Point(19, 245);
            this.income_tax_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.income_tax_label.Name = "income_tax_label";
            this.income_tax_label.Size = new System.Drawing.Size(95, 20);
            this.income_tax_label.TabIndex = 9;
            this.income_tax_label.Text = "Income Tax:";
            // 
            // tax_rate_label
            // 
            this.tax_rate_label.AutoSize = true;
            this.tax_rate_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tax_rate_label.Location = new System.Drawing.Point(20, 292);
            this.tax_rate_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.tax_rate_label.Name = "tax_rate_label";
            this.tax_rate_label.Size = new System.Drawing.Size(131, 18);
            this.tax_rate_label.TabIndex = 10;
            this.tax_rate_label.Text = "Marginal Tax Rate:";
            // 
            // tax_rate_output
            // 
            this.tax_rate_output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tax_rate_output.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tax_rate_output.Location = new System.Drawing.Point(175, 288);
            this.tax_rate_output.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.tax_rate_output.Name = "tax_rate_output";
            this.tax_rate_output.Size = new System.Drawing.Size(67, 26);
            this.tax_rate_output.TabIndex = 11;
            this.tax_rate_output.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // clear_button
            // 
            this.clear_button.BackColor = System.Drawing.Color.IndianRed;
            this.clear_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear_button.Location = new System.Drawing.Point(114, 184);
            this.clear_button.Name = "clear_button";
            this.clear_button.Size = new System.Drawing.Size(85, 30);
            this.clear_button.TabIndex = 12;
            this.clear_button.Text = "Clear";
            this.clear_button.UseVisualStyleBackColor = false;
            this.clear_button.Click += new System.EventHandler(this.clear_button_Click);
            // 
            // program_2
            // 
            this.AcceptButton = this.calculate_button;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 340);
            this.Controls.Add(this.clear_button);
            this.Controls.Add(this.tax_rate_output);
            this.Controls.Add(this.tax_rate_label);
            this.Controls.Add(this.income_tax_label);
            this.Controls.Add(this.income_tax_output);
            this.Controls.Add(this.calculate_button);
            this.Controls.Add(this.head_of_household_radio);
            this.Controls.Add(this.single_radio);
            this.Controls.Add(this.married_filing_separately_radio);
            this.Controls.Add(this.married_filing_jointly_radio);
            this.Controls.Add(this.tax_filing_status_label);
            this.Controls.Add(this.taxable_income_label);
            this.Controls.Add(this.taxable_income_text);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "program_2";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox taxable_income_text;
        private System.Windows.Forms.Label taxable_income_label;
        private System.Windows.Forms.Label tax_filing_status_label;
        private System.Windows.Forms.RadioButton married_filing_jointly_radio;
        private System.Windows.Forms.RadioButton married_filing_separately_radio;
        private System.Windows.Forms.RadioButton single_radio;
        private System.Windows.Forms.RadioButton head_of_household_radio;
        private System.Windows.Forms.Button calculate_button;
        private System.Windows.Forms.Label income_tax_output;
        private System.Windows.Forms.Label income_tax_label;
        private System.Windows.Forms.Label tax_rate_label;
        private System.Windows.Forms.Label tax_rate_output;
        private System.Windows.Forms.Button clear_button;
    }
}

