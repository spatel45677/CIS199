﻿// Grading ID - N6394
// Program 2
// Due Date - 03/05/19
// Course - Cis 199-75
// This program calculates income tax and shows the marginal tax rate by user input of income and tax filing status.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class program_2 : Form
    {
        public program_2() {
            InitializeComponent();
        }
        // Calculate Button to calculate income tax and tax rate
        private void calculate_button_Click(object sender, EventArgs e) {

            // tax percents to calculate tax
            const double tax_percent_7 = 0.37;
            const double tax_percent_6 = 0.35;
            const double tax_percent_5 = 0.32;
            const double tax_percent_4 = 0.24;
            const double tax_percent_3 = 0.22;
            const double tax_percent_2 = 0.12;
            const double tax_percent_1 = 0.10;

            //   Single tax brackets
            const int single_tax_bracket1 = 9700;
            const int single_tax_bracket2 = 39475;
            const int single_tax_bracket3 = 84200;
            const int single_tax_bracket4 = 160725;
            const int single_tax_bracket5 = 204100;
            const int single_tax_bracket6 = 510300;

            //   Married filing jointly tax brackets
            const int married_jointly_tax_bracket1 = 19400;
            const int married_jointly_tax_bracket2 = 78950;
            const int married_jointly_tax_bracket3 = 168400;
            const int married_jointly_tax_bracket4 = 321450;
            const int married_jointly_tax_bracket5 = 408200;
            const int married_jointly_tax_bracket6 = 612350;

            //   Married filing separately tax brackets
            const int married_separately_tax_bracket1 = 9700;
            const int married_separately_tax_bracket2 = 39475;
            const int married_separately_tax_bracket3 = 84200;
            const int married_separately_tax_bracket4 = 160725;
            const int married_separately_tax_bracket5 = 204100;
            const int married_separately_tax_bracket6 = 306175;

            //   Head of Household tax brackets
            const int head_household_tax_bracket1 = 13850;
            const int head_household_tax_bracket2 = 52850;
            const int head_household_tax_bracket3 = 84200;
            const int head_household_tax_bracket4 = 160700;
            const int head_household_tax_bracket5 = 204100;
            const int head_household_tax_bracket6 = 510300;

            double tax; // to add all tax from different tax brackets into one tax
            uint taxable_income; // user input of taxable income

            // to store tax of seperate tax brackets
            double tax_bracket1 = 0;
            double tax_bracket2 = 0;
            double tax_bracket3 = 0;
            double tax_bracket4 = 0;
            double tax_bracket5 = 0;
            double tax_bracket6 = 0;
            double tax_bracket7 = 0; 

            if (uint.TryParse(taxable_income_text.Text, out taxable_income)) // user input
            {    
                // Single
                if (single_radio.Checked) // checks if single radio button is checked
                {
                    // Single tax calculations
                    if (taxable_income > single_tax_bracket6){
                        tax_bracket7 = (taxable_income - single_tax_bracket6) * tax_percent_7;
                        tax_bracket6 = (single_tax_bracket6 - single_tax_bracket5) * tax_percent_6;
                        tax_bracket5 = (single_tax_bracket5 - single_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (single_tax_bracket4 - single_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (single_tax_bracket3 - single_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (single_tax_bracket2 - single_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (single_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_7:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > single_tax_bracket5 && taxable_income <= single_tax_bracket6){
                        tax_bracket6 = (taxable_income - single_tax_bracket5) * tax_percent_6;
                        tax_bracket5 = (single_tax_bracket5 - single_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (single_tax_bracket4 - single_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (single_tax_bracket3 - single_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (single_tax_bracket2 - single_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (single_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_6:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > single_tax_bracket4 && taxable_income <= single_tax_bracket5){
                        tax_bracket5 = (taxable_income - single_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (single_tax_bracket4 - single_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (single_tax_bracket3 - single_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (single_tax_bracket2 - single_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (single_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_5:P}"; // output of marginal tax rate
                    }
                    else if (taxable_income > single_tax_bracket3 && taxable_income <= single_tax_bracket4) {
                        tax_bracket4 = (taxable_income - single_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (single_tax_bracket3 - single_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (single_tax_bracket2 - single_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (single_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_4:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > single_tax_bracket2 && taxable_income <= single_tax_bracket3) {
                        tax_bracket3 = (taxable_income - single_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (single_tax_bracket2 - single_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (single_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_3:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > single_tax_bracket1 && taxable_income <= single_tax_bracket2) {
                        tax_bracket2 = (taxable_income - single_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (single_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_2:P0}"; // output of marginal tax rate
                    }
                    else {
                        tax_bracket1 = (taxable_income - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_1:P0}"; // output of marginal tax rate
                    }
                }


               //Married filing jointly
               else if (married_filing_jointly_radio.Checked) // checks if married jointly radio button is checked
                {
                    // married filing jointly tax calculations
                    if (taxable_income > married_jointly_tax_bracket6) {
                        tax_bracket7 = (taxable_income - married_jointly_tax_bracket6) * tax_percent_7;
                        tax_bracket6 = (married_jointly_tax_bracket6 - married_jointly_tax_bracket5) * tax_percent_6;
                        tax_bracket5 = (married_jointly_tax_bracket5 - married_jointly_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (married_jointly_tax_bracket4 - married_jointly_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (married_jointly_tax_bracket3 - married_jointly_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (married_jointly_tax_bracket2 - married_jointly_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_jointly_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_7:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > married_jointly_tax_bracket5 && taxable_income <= married_jointly_tax_bracket6) {
                        tax_bracket6 = (taxable_income - married_jointly_tax_bracket5) * tax_percent_6;
                        tax_bracket5 = (married_jointly_tax_bracket5 - married_jointly_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (married_jointly_tax_bracket4 - married_jointly_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (married_jointly_tax_bracket3 - married_jointly_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (married_jointly_tax_bracket2 - married_jointly_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_jointly_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_6:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > married_jointly_tax_bracket4 && taxable_income <= married_jointly_tax_bracket5) {
                        tax_bracket5 = (taxable_income - married_jointly_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (married_jointly_tax_bracket4 - married_jointly_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (married_jointly_tax_bracket3 - married_jointly_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (married_jointly_tax_bracket2 - married_jointly_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_jointly_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_5:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > married_jointly_tax_bracket3 && taxable_income <= married_jointly_tax_bracket4) {
                        tax_bracket4 = (taxable_income - married_jointly_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (married_jointly_tax_bracket3 - married_jointly_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (married_jointly_tax_bracket2 - married_jointly_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_jointly_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_4:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > married_jointly_tax_bracket2 && taxable_income <= married_jointly_tax_bracket3) {
                        tax_bracket3 = (taxable_income - married_jointly_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (married_jointly_tax_bracket2 - married_jointly_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_jointly_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_3:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > married_jointly_tax_bracket1 && taxable_income <= married_jointly_tax_bracket2) {
                        tax_bracket2 = (taxable_income - married_jointly_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_jointly_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_2:P0}"; // output of marginal tax rate
                    }
                    else {
                        tax_bracket1 = (taxable_income - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_1:P0}"; // output of marginal tax rate
                    }
                }


               // Married filing separately
               else if (married_filing_separately_radio.Checked)// checks if married filing separately radio button is checked
                {
                    // married filing separately tax calculations
                    if (taxable_income > married_separately_tax_bracket6) {
                        tax_bracket7 = (taxable_income - married_separately_tax_bracket6) * tax_percent_7;
                        tax_bracket6 = (married_separately_tax_bracket6 - married_separately_tax_bracket5) * tax_percent_6;
                        tax_bracket5 = (married_separately_tax_bracket5 - married_separately_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (married_separately_tax_bracket4 - married_separately_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (married_separately_tax_bracket3 - married_separately_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (married_separately_tax_bracket2 - married_separately_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_separately_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_7:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > married_separately_tax_bracket5 && taxable_income <= married_separately_tax_bracket6) {
                        tax_bracket6 = (taxable_income - married_separately_tax_bracket5) * tax_percent_6;
                        tax_bracket5 = (married_separately_tax_bracket5 - married_separately_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (married_separately_tax_bracket4 - married_separately_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (married_separately_tax_bracket3 - married_separately_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (married_separately_tax_bracket2 - married_separately_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_separately_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_6:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > married_separately_tax_bracket4 && taxable_income <= married_separately_tax_bracket5) {
                        tax_bracket5 = (taxable_income - married_separately_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (married_separately_tax_bracket4 - married_separately_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (married_separately_tax_bracket3 - married_separately_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (married_separately_tax_bracket2 - married_separately_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_separately_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_5:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > married_separately_tax_bracket3 && taxable_income <= married_separately_tax_bracket4) {
                        tax_bracket4 = (taxable_income - married_separately_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (married_separately_tax_bracket3 - married_separately_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (married_separately_tax_bracket2 - married_separately_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_separately_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_4:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > married_separately_tax_bracket2 && taxable_income <= married_separately_tax_bracket3) {
                        tax_bracket3 = (taxable_income - married_separately_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (married_separately_tax_bracket2 - married_separately_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_separately_tax_bracket1 - 0) * tax_percent_1;                   
                        tax_rate_output.Text = $"{tax_percent_3:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > married_separately_tax_bracket1 && taxable_income <= married_separately_tax_bracket2) {
                        tax_bracket2 = (taxable_income - married_separately_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (married_separately_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_2:P0}"; // output of marginal tax rate
                    }
                    else {
                        tax_bracket1 = (taxable_income - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_1:P0}"; // output of marginal tax rate
                    }
                }


                //Head of Household
                else if (head_of_household_radio.Checked)// checks if head of household radio button is checked
                {
                    // head of household tax calculations
                    if (taxable_income > head_household_tax_bracket6) {
                        tax_bracket7 = (taxable_income - head_household_tax_bracket6) * tax_percent_7;
                        tax_bracket6 = (head_household_tax_bracket6 - head_household_tax_bracket5) * tax_percent_6;
                        tax_bracket5 = (head_household_tax_bracket5 - head_household_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (head_household_tax_bracket4 - head_household_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (head_household_tax_bracket3 - head_household_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (head_household_tax_bracket2 - head_household_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (head_household_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_7:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > head_household_tax_bracket5 && taxable_income <= head_household_tax_bracket6) {
                        tax_bracket6 = (taxable_income - head_household_tax_bracket5) * tax_percent_6;
                        tax_bracket5 = (head_household_tax_bracket5 - head_household_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (head_household_tax_bracket4 - head_household_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (head_household_tax_bracket3 - head_household_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (head_household_tax_bracket2 - head_household_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (head_household_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_6:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > head_household_tax_bracket4 && taxable_income <= head_household_tax_bracket5) {
                        tax_bracket5 = (taxable_income - head_household_tax_bracket4) * tax_percent_5;
                        tax_bracket4 = (head_household_tax_bracket4 - head_household_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (head_household_tax_bracket3 - head_household_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (head_household_tax_bracket2 - head_household_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (head_household_tax_bracket1 - 0) * tax_percent_1;                  
                        tax_rate_output.Text = $"{tax_percent_5:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > head_household_tax_bracket3 && taxable_income <= head_household_tax_bracket4) {
                        tax_bracket4 = (taxable_income - head_household_tax_bracket3) * tax_percent_4;
                        tax_bracket3 = (head_household_tax_bracket3 - head_household_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (head_household_tax_bracket2 - head_household_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (head_household_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_4:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > head_household_tax_bracket2 && taxable_income <= head_household_tax_bracket3) {
                        tax_bracket3 = (taxable_income - head_household_tax_bracket2) * tax_percent_3;
                        tax_bracket2 = (head_household_tax_bracket2 - head_household_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (head_household_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_3:P0}"; // output of marginal tax rate
                    }
                    else if (taxable_income > head_household_tax_bracket1 && taxable_income <= head_household_tax_bracket2) {
                        tax_bracket2 = (taxable_income - head_household_tax_bracket1) * tax_percent_2;
                        tax_bracket1 = (head_household_tax_bracket1 - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_2:P0}"; // output of marginal tax rate
                    }
                    else {
                        tax_bracket1 = (taxable_income - 0) * tax_percent_1;
                        tax_rate_output.Text = $"{tax_percent_1:P0}"; // output of marginal tax rate
                    }
                }
                else {
                    MessageBox.Show("Select a tax filing status");// Informs to select a tax filing status
                }
                // adding all tax from seperate tax brackets into one variable 
                tax = tax_bracket1 + tax_bracket2 + tax_bracket3 + tax_bracket4 + tax_bracket5 + tax_bracket6 + tax_bracket7;
                income_tax_output.Text = $"{tax:C}"; // output of income tax
            }
            else
            {
                MessageBox.Show("Enter a valid number"); // Informs to enter a valid number
            }
        }
        // clear button
        private void clear_button_Click(object sender, EventArgs e)
        {
            taxable_income_text.Text = ""; //clears taxable income text box
            income_tax_output.Text = ""; //clears tax output box
            tax_rate_output.Text = ""; //clears tax rate box
            single_radio.Checked = false; // clears single radio button
            married_filing_separately_radio.Checked = false; // clears married filing separately radio button
            married_filing_jointly_radio.Checked = false; // clears married filing jointly radio button
            head_of_household_radio.Checked = false; // clears head of household radio button
        }
    }
}

