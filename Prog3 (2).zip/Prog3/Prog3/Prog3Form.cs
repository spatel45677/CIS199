﻿// Grading ID - 
// Program 3
// CIS 199-75
// Due: 3/30/2019

// This application calculates the marginal tax rate and
// tax due for filers in 2019 tax year.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog3
{
    public partial class Prog3Form : Form
    {
        // Tax Year 2019 Data
        // Taxable income thresholds for each status
        // Single Filers
        int[] single_threshold = { 1, 9701, 39476, 84201, 160726, 204101, 510301 };   // single threshold

        //Married Filing Separately
        int[] seperately_threshold = { 1, 9701, 39476, 84201, 160726, 204101, 306176 };   // married-separately threshold

        // Married Filing Jointly
        int[] jointly_threshold = { 1, 19401, 78951, 168401, 321451, 408201, 612351 };  // married-jointly threshold

        // Head of Household
        int[] household_threshold = { 1, 13851, 52851, 84201, 160701, 204101, 510301 };  //head of household threshold       

        // Income threshold values that apply to this filer
        int [] threshold = new int [7]; // 1st income threshold


        public Prog3Form()
        {
            InitializeComponent();
        }

        // User has clicked the Calculate Tax button
        // Will calculate and display their marginal tax rate and tax due
        private void calcTaxBtn_Click(object sender, EventArgs e)
        {
       
            decimal[] rates = { .10m, 0.12m, 0.22m, 0.24m, 0.32m, 0.35m, 0.37m };
            

            int income; // Filer's taxable income (input)

            decimal marginalRate; // Filer's calculated marginal tax rate
            decimal tax = 0;          // Filer's calculated income tax due
            decimal currentTax;   // Filer's tax for current tier
            bool found = false;




            if (int.TryParse(incomeTxt.Text, out income) && income >= 0)
            {
                // Calculate income tax due and find their marginal rate
                // Uses running total approach
                // Math.Min returns the smaller of two values

                int index = rates.Length -1;

                while (index >= 0 && !found) // keeps looping until greater than 0 and not found
                {
                    if (income >= threshold[index])
                        found = true;
                    else
                        --index;
                }
                if (found)
                {
                    marginalRateOutLbl.Text = ($"{rates[index]:P0}");
                }


                int i;

                for (i = 0; i <= index; ++i)
                {
                    currentTax = Math.Min((income - (threshold[i] - 1)), ((threshold[i + 1]) - (threshold[i]))) * rates[i];
                    tax += currentTax;
                }









                // Output results
                taxOutLbl.Text = $"{tax:C}";
            }
            else // Invalid input
                MessageBox.Show("Enter valid income!");
        }

        // Form is loading
        // Sets default filing status as Single
        private void Prog2Form_Load(object sender, EventArgs e)
        {
            singleRdoBtn.Checked = true; // Choose single by default
                                         // Will raise CheckedChanged event
        }

        // User has checked/unchecked Single radio button
        // Updates income thresholds
        private void singleRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (singleRdoBtn.Checked) // Single?
            {
                threshold[0] = single_threshold[0];                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                threshold[1] = single_threshold[1];
                threshold[2] = single_threshold[2];
                threshold[3] = single_threshold[3];
                threshold[4] = single_threshold[4];
                threshold[5] = single_threshold[5];
                threshold[6] = single_threshold[6];
            }
        }

        // User has checked/unchecked Married Filing Separately radio button
        // Updates income thresholds
        private void separatelyRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (separatelyRdoBtn.Checked) // Married Filing Separately?
            {
                threshold[0] = seperately_threshold[0];
                threshold[1] = seperately_threshold[1];
                threshold[2] = seperately_threshold[2];
                threshold[3] = seperately_threshold[3];
                threshold[4] = seperately_threshold[4];
                threshold[5] = seperately_threshold[5];
                threshold[6] = seperately_threshold[6];
            }
        }

        // User has checked/unchecked Married Filing Jointly radio button
        // Updates income thresholds
        private void jointlyRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (jointlyRdoBtn.Checked) // Married Filing Jointly?
            {
                threshold[0] = jointly_threshold[0];
                threshold[1] = jointly_threshold[1];
                threshold[2] = jointly_threshold[2];
                threshold[3] = jointly_threshold[3];
                threshold[4] = jointly_threshold[4];
                threshold[5] = jointly_threshold[5];
                threshold[6] = jointly_threshold[6];
            }
        }

        // User has checked/unchecked Head of Household radio button
        // Updates income thresholds
        private void headOfHouseRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (headOfHouseRdoBtn.Checked) // Head of Household?
            {
                threshold[0] = household_threshold[0];
                threshold[1] = household_threshold[1];
                threshold[2] = household_threshold[2];
                threshold[3] = household_threshold[3];
                threshold[4] = household_threshold[4];
                threshold[5] = household_threshold[5];
                threshold[6] = household_threshold[6];
            }
        }
    }
}
