﻿// Grading ID - N6394
// Program 1
// due date - 02/12/19
// CIS 199-75
// This program is carpet estimator that calculates sq. yards needed and the costs.

using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_1
{
    class Program
    {
        static void Main(string[] args)
        {

            const double feet_to_yard = 9; // constant for feet to yard conversion
            const double carpet_waste = 0.10; // rate of carpet waste
            const double padding_excess = 0.10; // rate of padding excess
            const double padding_rate = 2.75; // per sq. yard padding rate for each layer
            const double labor_rate = 4.50; // labor charge per sq. yard

            double width; // user input of max width
            double length; // user input of max length
            double price; // user input of carpet price
            int padding; // user input of layers of padding
            int first_room; // user input of first room or not

            double yards_needed; // yards needed calculation
            double carpet_cost; // carpet cost calculation
            double padding_cost; // padding cost calculation
            double labor_cost; // labor cost calculation
            double total_cost; // total cost calculation


            WriteLine("Welcome to the Handy-Dandy Carpet Estimator");
            WriteLine(" ");


            // User Input
            Write("Enter the max width of room (in feet): "); 
            width = double.Parse(ReadLine());

            Write("Enter the max length of room (in feet): "); 
            length = double.Parse(ReadLine());

            Write("Enter the carpet price (per sq. yard): "); 
            price = double.Parse(ReadLine());

            Write("Enter layers of padding to use (1 or 2): "); 
            padding = int.Parse(ReadLine());
            
            Write("Is this the first room? (1 = YES, 0 = NO): "); 
            first_room = int.Parse(ReadLine());
            if (first_room == 1) { first_room = 100; }
            else if (first_room == 2) { first_room = 0;}


            WriteLine(" ");


            // Calculation / Output
            yards_needed = length * width / feet_to_yard;     
            WriteLine($"Sq. Yards Needed:{yards_needed,10:N1}");

            carpet_cost = (yards_needed * price) * carpet_waste + (yards_needed * price);
            WriteLine($"Carpet Cost:{carpet_cost,16:C}");

            padding_cost = padding * ((yards_needed * padding_rate) * padding_excess + (yards_needed * padding_rate));
            WriteLine($"Padding Cost:{padding_cost,15:C}");

            labor_cost = yards_needed * labor_rate + first_room;
            WriteLine ($"Labor Cost:{labor_cost,17:C}");

            total_cost = carpet_cost + padding_cost + labor_cost;
            WriteLine ($"Total Cost:{total_cost,17:C}");



        }
    }
}
