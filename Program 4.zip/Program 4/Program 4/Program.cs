﻿// Grading ID - N6394
// lab number - Program 4
// due date - 04/23/19
// course - CIS 199-75
// description - This program allows user to print out
//               each properties for different packages.

using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class Program
    {
        static void Main(string[] args)
        {
            // GroundPackage Class objects
            GroundPackage p1 = new GroundPackage(40214, 50222, 2.3, 3.1, 4.3, 2.8);
            GroundPackage p2 = new GroundPackage(98214, 80222, 1.3, 8.1, 2.9, 4.1);
            GroundPackage p3 = new GroundPackage(23523, 12345, 9.7, 5.3, 7.2, 6.1);
            GroundPackage p4 = new GroundPackage(98765, 76543, 3.9, 2.4, 5.9, 2.8);
            GroundPackage p5 = new GroundPackage(34567, 25246, 8.3, 4.6, 8.0, 3.8);

            // 5 elements package array
            GroundPackage[] packages = new GroundPackage[5];

            packages[0] = p1;
            packages[1] = p2;
            packages[2] = p3;
            packages[3] = p4;
            packages[4] = p5;

            // invoke display package method
            DisplayPackages(packages);

            WriteLine($"New data{Environment.NewLine}");

            // changed data for each package
            packages[0].OriginZip = 465321;
            packages[0].DestinationZip = 64631;
            packages[0].Length = -6.3;
            packages[0].Width = 45.1;
            packages[0].Height = 516.3;
            packages[0].Weight = 19.8;

            packages[1].OriginZip = 4024;
            packages[1].DestinationZip = 64652;
            packages[1].Length = 26.3;
            packages[1].Width = 38.1;
            packages[1].Height = 43.3;
            packages[1].Weight = 27.8;

            packages[2].OriginZip = 40214;
            packages[2].DestinationZip = 50222;
            packages[2].Length = 92.3;
            packages[2].Width = 36.1;
            packages[2].Height = 74.3;
            packages[2].Weight = 12.8;

            packages[3].OriginZip = 40214;
            packages[3].DestinationZip = 50222;
            packages[3].Length = 52.3;
            packages[3].Width = 36.1;
            packages[3].Height = 48.3;
            packages[3].Weight = 29.8;

            packages[4].OriginZip = 40214;
            packages[4].DestinationZip = 50222;
            packages[4].Length = 246.1;
            packages[4].Width = 384.6;
            packages[4].Height = 49.0;
            packages[4].Weight = 210.9;

            // invoke display package method
            DisplayPackages(packages);
        }

        // non-value returning method to display packages
        public static void DisplayPackages(GroundPackage[] _packages)
        {
            foreach (GroundPackage display_packages in _packages) // foreach loop to print all properties in packages.
            {
                WriteLine(display_packages.ToString());
                WriteLine($"Cost: {display_packages.CalcCost()} {Environment.NewLine}");
            }
        }
    }
}
