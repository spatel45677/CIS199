﻿// Grading ID - N6394
// lab number - Program 4
// due date - 04/23/19
// course - CIS 199-75
// description - This program allows user to print out
//               each properties for different packages.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class GroundPackage
    {
        private int _originZip; // backing field for origin zipcode
        private int _destinationZip; // backing field for destination zipcode
        private double _length; // backing field for length
        private double _width; // backing field for width
        private double _height; // backing field for height
        private double _weight; // backing field for weight

        // Constants
        const int origin_zip_min = 00000; // min. for origin zip
        const int origin_zip_max = 99999; // max. for orgin zip
        const int orgin_zip_default = 40202;// default for orgin zip
        const int destination_zip_min = 000000;// min. for destination zip
        const int destination_zip_max = 99999;// max. for destination zip
        const int destination_zip_default = 90210;// default for destination zip
        const double length_min = 0;// min. for length
        const double length_default = 1.0;// default for length
        const double width_min = 0;// min. for width
        const double width_default = 1.0;// default for width
        const double height_min = 0;// min. for height
        const double height_default = 1.0;// default for height
        const double weight_min = 0;// min. for weight
        const double weight_default = 1.0;// default for weight
        const double SIZE_COST_FACTOR = 0.25; // size cost factor
        const double WEIGHT_COST_FACTOR = 0.45; // weight cost factor

        public int OriginZip
        {
            get
            {
                // Precondition:  None
                // Postcondition: The Origin Zipcode has been returned
                return _originZip;
            }

            // Precondition:  00000 <= value <= 99999
            // Postcondition: The zip has been set to the specified value
            set
            {
                if(value >= origin_zip_min && value <= origin_zip_max)
                {
                    _originZip = value;
                }
                else
                {
                    _originZip = orgin_zip_default;
                }
            }
        }

        public int DestinationZip
        {
            // Precondition:  None
            // Postcondition: The Destination Zipcode has been returned
            get
            {
                return _destinationZip;
            }

            // Precondition:  00000 <= value <= 99999
            // Postcondition: The zip has been set to the specified value
            set
            {
                if (value >= destination_zip_min && value <= destination_zip_max)
                {
                    _destinationZip = value;
                }
                else
                {
                    _destinationZip = destination_zip_default;
                }
            }
        }

        public double Length
        {
            // Precondition:  None
            // Postcondition: The Length has been returned
            get
            {
                return _length;
            }

            // Precondition:  value >= 0
            // Postcondition: The length has been set to the specified value
            set
            {
                if (value > length_min)
                {
                    _length = value;
                }
                else
                {
                    _length = length_default;
                }
            }
        }

        public double Width
        {
            // Precondition:  None
            // Postcondition: The width has been returned
            get
            {
                return _width;
            }

            // Precondition:  value >= 0
            // Postcondition: The width has been set to the specified value
            set
            {
                if (value > width_min)
                {
                    _width = value;
                }
                else
                {
                    _width = width_default;
                }
            }
        }

        public double Height
        {
            // Precondition:  None
            // Postcondition: The height has been returned
            get
            {
                return _height;
            }

            // Precondition:  value >= 0
            // Postcondition: The height has been set to the specified value
            set
            {
                if (value > height_min)
                {
                    _height = value;
                }
                else
                {
                    _height = height_default;
                }
            }
        }

        public double Weight
        {
            // Precondition:  None
            // Postcondition: The weight has been returned
            get
            {
                return _weight;
            }

            // Precondition:  value >= 0
            // Postcondition: The weight has been set to the specified value
            set
            {
                if (value > weight_min)
                {
                    _weight = value;
                }
                else
                {
                    _weight = weight_default;
                }
            }
        }

        public int ZoneDistance
        {
            // Precondition:  None
            // Postcondition: The zone distance has been returned
            get
            {
                int zonedistance;
                zonedistance = Math.Abs((_originZip / 10000) - (_destinationZip / 10000));

                return zonedistance;
            }
        }

        // Precondition:  00000 <= zip <= 99999, (length, width, height, weight) >= 0
        // Postcondition: The ground package has been initialized with the specified
        //                values for origin zip, destination zip, length, width, height, weight.
        public GroundPackage(int origin_zip, int destination_zip, double length, double width, double height, double weight)
        {
            OriginZip = origin_zip;
            DestinationZip = destination_zip;
            Length = length;
            Width = width;
            Height = height;
            Weight = weight;

        }

        // Precondition:  None
        // Postcondition: A double is returned in Cost
        public double CalcCost()
        {
            double Cost; // to calculate cost
            Cost = SIZE_COST_FACTOR * (Length + Width + Height) + WEIGHT_COST_FACTOR * (ZoneDistance + 1) * (Weight);
            return Cost;
        }

        // Precondition:  None
        // Postcondition: Package's properties are returned as formatted string.
        public override string ToString()
        {
            return
                $"OriginZip: {OriginZip} {Environment.NewLine}" +
                $"DestinationZip: {DestinationZip} {Environment.NewLine}" +
                $"Length: {Length} {Environment.NewLine}" +
                $"Width: {Width} {Environment.NewLine}" +
                $"Height: {Height} {Environment.NewLine}" +
                $"Weight: {Weight}";
        }

    }
}
